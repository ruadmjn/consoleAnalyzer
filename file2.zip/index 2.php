<?php
$var = "gg";
$a = $_POST['a'];
echo $a
$c = $_POST['c'];
echo $a
$b = $_POST['b'];
$c = $b;
echo $c;
echo $b;
echo $_POST['login'];
?>