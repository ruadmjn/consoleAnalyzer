<?php
$var = "gg";
htmlspecialchars($a) = $_POST['a'];
$b = $_POST['b'];
$a = $b;
echo $a;
echo $b;
echo $_POST['login'];
?>