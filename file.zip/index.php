<?php
$var = "gg";
htmlspecialchars($a) = $_POST['a'];
$b = $_POST['b'];
$a = $b;
echo $a;
echo $_POST['login'];
?>