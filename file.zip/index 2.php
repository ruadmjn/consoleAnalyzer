<?php
$var = "gg";
$a = $_POST['a'];
$b = htmlspecialchars($_POST['b']);
$a = $b;
echo $a;
echo $b;
echo $_POST['login'];
?>